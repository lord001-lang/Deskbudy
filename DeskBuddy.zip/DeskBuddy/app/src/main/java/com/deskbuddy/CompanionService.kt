package com.deskbuddy

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.*
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import java.util.Calendar
import kotlin.math.abs

class CompanionService : Service() {
    companion object { var instance: CompanionService? = null }

    private lateinit var wm: WindowManager
    private lateinit var face: FaceView
    private val h = Handler(Looper.getMainLooper())
    private val revert = Runnable { face.mood = baseMood() }

    override fun onBind(i: Intent?): IBinder? = null

    private fun baseMood(): Mood {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (hr >= 23 || hr < 6) Mood.SLEEPY else Mood.IDLE
    }

    fun react(m: Mood, ms: Long = 4000) {
        h.post {
            h.removeCallbacks(revert)
            face.mood = m
            h.postDelayed(revert, ms)
        }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> react(Mood.LOVE, 6000)
                Intent.ACTION_POWER_DISCONNECTED -> react(Mood.SURPRISE, 3000)
                Intent.ACTION_BATTERY_LOW -> react(Mood.SAD, 10000)
                Intent.ACTION_USER_PRESENT -> react(Mood.HAPPY, 4000)
                Intent.ACTION_HEADSET_PLUG ->
                    if (i.getIntExtra("state", 0) == 1) react(Mood.MUSIC, 6000) else react(Mood.SAD, 2500)
                AudioManager.ACTION_AUDIO_BECOMING_NOISY -> react(Mood.SAD, 2500)
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> react(Mood.SURPRISE, 3000)
                Intent.ACTION_TIME_TICK -> if (face.mood == Mood.IDLE || face.mood == Mood.SLEEPY) face.mood = baseMood()
                TelephonyManager.ACTION_PHONE_STATE_CHANGED -> when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                    TelephonyManager.EXTRA_STATE_RINGING -> react(Mood.CALL, 60000)
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> react(Mood.HAPPY, 3000)
                    else -> react(Mood.IDLE, 1)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buddy", "DeskBuddy", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "buddy")
            .setContentTitle("DeskBuddy is running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        face = FaceView(this)
        val d = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            (150 * d).toInt(), (110 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        face.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = sx + dx; lp.y = sy + dy
                    wm.updateViewLayout(face, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) react(Mood.HAPPY, 2500)
            }
            true
        }
        face.mood = baseMood()
        wm.addView(face, lp)

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_HEADSET_PLUG); addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED); addAction(Intent.ACTION_TIME_TICK)
            addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(rx, f)
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        instance = null
        h.removeCallbacksAndMessages(null)
        unregisterReceiver(rx)
        wm.removeView(face)
        super.onDestroy()
    }
}
