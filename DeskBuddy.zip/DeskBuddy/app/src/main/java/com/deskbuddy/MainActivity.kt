package com.deskbuddy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { a() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }.also { col.addView(it) }

        col.addView(TextView(this).apply { text = "DeskBuddy"; textSize = 26f })
        btn("1. Allow draw over apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow notification access (face reacts to notifications)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Start companion") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Do step 1 first", Toast.LENGTH_SHORT).show()
            } else {
                val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE)
                if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                requestPermissions(perms.toTypedArray(), 1)
                startForegroundService(Intent(this, CompanionService::class.java))
            }
        }
        btn("Stop companion") { stopService(Intent(this, CompanionService::class.java)) }

        col.addView(TextView(this).apply { text = "\nTest expressions:" })
        Mood.values().forEach { m -> btn(m.name) { CompanionService.instance?.react(m, 4000) } }

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
