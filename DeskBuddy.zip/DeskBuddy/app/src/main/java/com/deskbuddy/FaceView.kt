package com.deskbuddy

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.random.Random

enum class Mood { IDLE, HAPPY, SLEEPY, LOVE, ALERT, SAD, CALL, MUSIC, SURPRISE }

class FaceView(ctx: Context) : View(ctx) {
    var mood = Mood.IDLE
        set(v) { field = v; invalidate() }

    private var blink = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blinkAnim = ValueAnimator.ofFloat(1f, 0.05f, 1f).apply {
        duration = 180
        addUpdateListener { blink = it.animatedValue as Float; invalidate() }
    }
    private val blinker = object : Runnable {
        override fun run() {
            blinkAnim.start()
            postDelayed(this, Random.nextLong(2500, 6000))
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postDelayed(blinker, 3000)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(blinker)
        blinkAnim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0xFF0B0F14.toInt()
        c.drawRoundRect(0f, 0f, w, h, h * 0.3f, h * 0.3f, p)

        val col = when (mood) {
            Mood.LOVE -> 0xFFFF4D6D
            Mood.ALERT, Mood.SURPRISE -> 0xFFFFD166
            Mood.SAD -> 0xFF6C9BFF
            Mood.CALL -> 0xFF5CFF9D
            else -> 0xFF3DE0FF
        }.toInt()
        p.color = col

        val ex = floatArrayOf(w * 0.30f, w * 0.70f)
        val ey = h * 0.40f
        val rw = w * 0.09f
        val rh = h * 0.16f
        val stroke = Paint(p).apply { style = Paint.Style.STROKE; strokeWidth = h * 0.045f; strokeCap = Paint.Cap.ROUND }
        val text = Paint(p).apply { textAlign = Paint.Align.CENTER }

        // eyes
        for (x in ex) {
            when (mood) {
                Mood.IDLE -> c.drawOval(RectF(x - rw, ey - rh * blink, x + rw, ey + rh * blink), p)
                Mood.SAD -> c.drawOval(RectF(x - rw, ey - rh * 0.7f * blink, x + rw, ey + rh * 0.7f * blink), p)
                Mood.ALERT, Mood.SURPRISE -> c.drawCircle(x, ey, rw * 1.3f, p)
                Mood.HAPPY, Mood.CALL, Mood.MUSIC ->
                    c.drawArc(RectF(x - rw, ey - rh * 0.6f, x + rw, ey + rh * 0.6f), 200f, 140f, false, stroke)
                Mood.SLEEPY -> c.drawLine(x - rw, ey, x + rw, ey, stroke)
                Mood.LOVE -> { text.textSize = h * 0.36f; c.drawText("\u2764", x, ey + h * 0.12f, text) }
            }
        }

        // mouth
        val cx = w / 2
        when (mood) {
            Mood.IDLE, Mood.HAPPY, Mood.LOVE, Mood.CALL, Mood.MUSIC ->
                c.drawArc(RectF(w * 0.4f, h * 0.58f, w * 0.6f, h * 0.78f), 20f, 140f, false, stroke)
            Mood.SAD -> c.drawArc(RectF(w * 0.42f, h * 0.7f, w * 0.58f, h * 0.9f), 200f, 140f, false, stroke)
            Mood.ALERT, Mood.SURPRISE -> c.drawCircle(cx, h * 0.74f, h * 0.07f, stroke)
            Mood.SLEEPY -> c.drawLine(cx - w * 0.04f, h * 0.72f, cx + w * 0.04f, h * 0.72f, stroke)
        }

        // extras
        text.textSize = h * 0.22f
        when (mood) {
            Mood.SLEEPY -> c.drawText("z", w * 0.88f, h * 0.25f, text)
            Mood.MUSIC -> c.drawText("\u266A", w * 0.88f, h * 0.25f, text)
            Mood.CALL -> c.drawText("\uD83D\uDCDE", w * 0.88f, h * 0.25f, text)
            Mood.ALERT -> c.drawText("!", w * 0.88f, h * 0.25f, text)
            else -> {}
        }
    }
}
