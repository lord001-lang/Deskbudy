# DeskBuddy
Floating face that reacts to phone events (charging, low battery, notifications, calls, headphones, unlock, airplane mode, night = sleepy, tap = happy). Drag to move.

Build: open in Android Studio and Run, OR push to GitHub -> Actions -> "Build APK" -> download artifact app-debug.apk.
First run: grant "draw over apps" + notification access, then Start.
